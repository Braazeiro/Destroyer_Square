#pragma once

class Bullet
{
private:
	float x, y, height, width, menorX, maiorX, menorY, maiorY;
	bool up, rightt;
	bool alive = true;
public:
	Bullet() : x(0), y(0), height(0), width(0), menorX(0), maiorX(0), menorY(0), maiorY(0), up(true), rightt(true)
	{

	}
	Bullet(float x, float y, float height, float width) : x(x), y(y), height(height), width(width)
	{

	}
	void Draw()
	{
		menorX = x - width / 2;
		maiorX = x + width / 2;
		menorY = y - height / 2;
		maiorY = y + height / 2;

		glColor3f(0.0f, 0.8f, 0.8f);
		glBegin(GL_QUADS);
		glVertex2f(menorX, menorY);
		glVertex2f(maiorX, menorY);
		glVertex2f(maiorX, maiorY);
		glVertex2f(menorX, maiorY);
		glEnd();

	}

	void SetSPEEDUpAndRight()
	{
		if (rightt == true)
		{
			x += 1;
		}
		else
		{
			if (rightt == false)
			{
				x -= 1;
			}
		}
		if (up == true)
		{
			y += 1;
		}
		else
		{
			if (up == false)
			{
				y -= 1;
			}
		}
	}

	void SetUpAndRightWINDOW(float minMaxX, float minMaxY)
	{
		if (maiorY >= minMaxY)
		{
			up = false;
		}

		if (menorX <= -minMaxX)
		{
			rightt = true;
		}
		else
		{
			if (maiorX >= minMaxX)
			{
				rightt = false;
			}
		}
	}

	void SetUpAndRightPLAYER(float menorX2, float maiorX2, float menorY2, float maiorY2, float minMaxX, float minMaxY)
	{

		if (menorX >= menorX2 && menorX <= maiorX2 ||
			maiorX >= menorX2 && maiorX <= maiorX2)
		{
			if (menorY <= maiorY2 && menorY > maiorY2 - 10)
			{
				up = true;
			}
			if (maiorY >= menorY2 && maiorY < menorY2 + 10)
			{
				up = false;
			}
		}

		if (menorY >= menorY2 && menorY <= maiorY2 ||
			maiorY >= menorY2 && maiorY <= maiorY2)
		{
			if (menorX <= maiorX2 && menorX > maiorX2 - 10)
			{
				rightt = true;
			}
			if (maiorX >= menorX2 && maiorX < menorX2 + 10)
			{
				rightt = false;

			}
		}
	}
	void SetAlive(bool a)
	{
		alive = a;
	}
	bool GetAlive()
	{
		return(alive);
	}
	void SetUp(int u)
	{
		up = u;
	}
	void SetRightt(int r)
	{
		rightt = r;
	}
	/////////////////////////
	float GetUp()
	{
		return(up);
	}
	float GetRightt()
	{
		return(rightt);
	}
	/////////////////////////
	void SetMoveX(int m)
	{
		x += m;
	}
	void SetMoveY(int m)
	{
		y += m;
	}
	void SetX(int m)
	{
		x = m;
	}
	void SetY(int m)
	{
		y = m;
	}
	/////////////////////////
	float GetX()
	{
		return(x);
	}
	float GetY()
	{
		return(y);
	}
	/////////////////////////
	float GetHeightBy2()
	{
		return(height / 2);
	}
	float GetWidthBy2()
	{
		return(width / 2);
	}
	/////////////////////////
	float GetMenorX()
	{
		return(menorX);
	}
	float GetMaiorX()
	{
		return(maiorX);
	}
	float GetMenorY()
	{
		return(menorY);
	}
	float GetMaiorY()
	{
		return(maiorY);
	}
	/////////////////////////
};

