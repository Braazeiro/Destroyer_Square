#pragma once

class Enemy
{
private:
	float x, y, height, width, menorX, maiorX, menorY, maiorY;
	bool alive = true;
public:
	Enemy() : x(0), y(0), height(0), width(0)
	{

	}
	Enemy(float x, float y, float alt, float comp) : x(x), y(y), height(alt), width(comp)
	{

	}
	void Draw()
	{
		menorX = x - height / 2;
		maiorX = x + height / 2;
		menorY = y - width / 2;
		maiorY = y + width / 2;

		glBegin(GL_POLYGON);
		glColor3f(0.7f, 0.0f, 0.0f);

		glVertex2i(x - width / 2, y - height / 3);
		glVertex2i(x - width / 3, y - height / 2);

		glVertex2i(x + width / 3, y - height / 2);
		glVertex2i(x + width / 2, y - height / 3);

		glVertex2i(x + width / 2, y + height / 3);
		glVertex2i(x + width / 3, y + height / 2);

		glVertex2i(x - width / 3, y + height / 2);
		glVertex2i(x - width / 2, y + height / 3);

		//////////////////////////////////////

		//glColor3f(0.7f, 0.3f, 0.0f);
		//glColor3f(0.7f, 0.4f, 0.2f);
		//glColor3f(0.3f, 0.8f, 0.1f);
		//glColor3f(0.7f, 0.0f, 0.1f);
		//glColor3f(0.4f, 0.0f, 0.1f);
		//glColor3f(0.7f, 0.1f, 0.0f);
		//glColor3f(0.7f, 0.3f, 0.0f);

		//////////////////////////////////////

		//glVertex2i(x, y);

		/*glVertex2i(x - comp / 2, y - alt / 2.25);
		glVertex2i(x - comp / 2.5, y - alt / 1.75);
		glVertex2i(x + comp / 2.5, y - alt / 1.75);
		glVertex2i(x + comp / 2, y - alt / 2.25);
		glVertex2i(x + comp / 2, y + alt / 2.25);
		glVertex2i(x + comp / 2.5, y + alt / 1.75);
		glVertex2i(x - comp / 2.5, y + alt / 1.75);
		glVertex2i(x - comp / 2, y + alt / 2.25);*/

		/*glVertex2i(x - comp / 2, y - alt / 2);
		glVertex2i(x + comp / 2, y - alt / 2);
		glVertex2i(x + comp / 2, y + alt / 2);
		glVertex2i(x - comp / 2, y + alt / 2);*/

		//////////////////////////////////////

		/*glVertex2i(x, y - alt / 2);
		glVertex2i(x + comp / 2, y);
		glVertex2i(x, y + alt / 2);
		glVertex2i(x - comp / 2, y);*/

		/*glVertex2i(x - comp / 12, y - alt / 2);
		glVertex2i(x + comp / 12, y - alt / 2);
		glVertex2i(x + comp / 12, y + alt / 2);
		glVertex2i(x - comp / 12, y + alt / 2);

		glVertex2i(x - comp / 2, y - alt / 12);
		glVertex2i(x + comp / 2, y - alt / 12);
		glVertex2i(x + comp / 2, y + alt / 12);
		glVertex2i(x - comp / 2, y + alt / 12);*/
		//glVertex2i(x + comp / 2, y);
		//glVertex2i(x, y + alt / 2);
		//glVertex2i(x - comp / 2, y);

		glEnd();

		glBegin(GL_POLYGON);
		glColor3f(0.4f, 0.0f, 0.05f);

		glVertex2i(x - width / 3, y - height / 4);
		glVertex2i(x - width / 4, y - height / 3);

		glVertex2i(x + width / 4, y - height / 3);
		glVertex2i(x + width / 3, y - height / 4);

		glVertex2i(x + width / 3, y + height / 4);
		glVertex2i(x + width / 4, y + height / 3);

		glVertex2i(x - width / 4, y + height / 3);
		glVertex2i(x - width / 3, y + height / 4);

		glEnd();

		//////////////////////////////////////

		//glVertex2i(x - comp / 3, y - alt / 3);
		//glVertex2i(x + comp / 3, y - alt / 3);
		//glVertex2i(x + comp / 3, y + alt / 3);
		//glVertex2i(x - comp / 3, y + alt / 3);

		//////////////////////////////////////

		/*glBegin(GL_LINE_LOOP);
		glColor3f(0.4f, 0.0f, 0.05f);

		glVertex2i(x - comp / 3, y - alt / 4);
		glVertex2i(x - comp / 4, y - alt / 3);

		glVertex2i(x + comp / 4, y - alt / 3);
		glVertex2i(x + comp / 3, y - alt / 4);

		glVertex2i(x + comp / 3, y + alt / 4);
		glVertex2i(x + comp / 4, y + alt / 3);

		glVertex2i(x - comp / 4, y + alt / 3);
		glVertex2i(x - comp / 3, y + alt / 4);

		glEnd();

		glBegin(GL_LINES);
		glColor3f(0.4f, 0.0f, 0.05f);
		glVertex2i(x - comp / 2, y - alt / 3);
		glVertex2i(x - comp / 3, y - alt / 4);

		glVertex2i(x - comp / 3, y - alt / 2);
		glVertex2i(x - comp / 4, y - alt / 3);

		glVertex2i(x + comp / 3, y - alt / 2);
		glVertex2i(x + comp / 4, y - alt / 3);

		glVertex2i(x + comp / 3, y - alt / 4);
		glVertex2i(x + comp / 2, y - alt / 3);

		glVertex2i(x + comp / 3, y + alt / 4);
		glVertex2i(x + comp / 2, y + alt / 3);

		glVertex2i(x + comp / 4, y + alt / 3);
		glVertex2i(x + comp / 3, y + alt / 2);

		glVertex2i(x - comp / 4, y + alt / 3);
		glVertex2i(x - comp / 3, y + alt / 2);

		glVertex2i(x - comp / 3, y + alt / 4);
		glVertex2i(x - comp / 2, y + alt / 3);

		/////////////////////////////////////

		glVertex2i(x - comp / 3, y - alt / 4);
		glVertex2i(x - comp / 4, y - alt / 3);

		glVertex2i(x + comp / 4, y - alt / 3);
		glVertex2i(x + comp / 3, y - alt / 4);

		glVertex2i(x + comp / 3, y + alt / 4);
		glVertex2i(x + comp / 4, y + alt / 3);

		glVertex2i(x - comp / 4, y + alt / 3);
		glVertex2i(x - comp / 3, y + alt / 4);

		glEnd();*/

	}
	bool Collision(float menorx, float maiorx, float menory, float maiory)
	{
		if (y + height / 2 < menory) return false;
		else if (y - height / 2 > maiory) return false;
		else if (x + width / 2 < menorx) return false;
		else if (x - width / 2 > maiorx) return false;

		return true;
	}
	/////////////////////////
	void SetAlive(bool a)
	{
		alive = a;
	}

	bool GetAlive()
	{
		return(alive);
	}
	/////////////////////////
	void SetMoveX(int m)
	{
		x += m;
	}
	void SetMoveY(int m)
	{
		y += m;
	}
	void SetX(int m)
	{
		x = m;
	}
	void SetY(int m)
	{
		y = m;
	}
	/////////////////////////
	float GetX()
	{
		return(x);
	}
	float GetY()
	{
		return(y);
	}
	/////////////////////////
	float GetHeightBy2()
	{
		return(height / 2);
	}
	float GetWidthBy2()
	{
		return(width / 2);
	}
	/////////////////////////
	float GetMenorX()
	{
		return(menorX);
	}
	float GetMaiorX()
	{
		return(maiorX);
	}
	float GetMenorY()
	{
		return(menorY);
	}
	float GetMaiorY()
	{
		return(maiorY);
	}
	/////////////////////////
};
