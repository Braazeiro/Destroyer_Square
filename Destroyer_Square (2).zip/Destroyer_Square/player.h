#pragma once

class Player
{
private:
	float x, y, alt, comp, moveX, moveY;
public:
	Player() : x(0), y(0), alt(0), comp(0)
	{

	}
	Player(float x, float y, float alt, float comp) : x(x), y(y), alt(alt), comp(comp)
	{

	}
	void Draw()
	{
		glColor3f(0.0f, 0.3f, 0.3f);
		glBegin(GL_QUADS);
		glVertex2f(x - comp / 2, y - alt / 2);
		glVertex2f(x + comp / 2, y - alt / 2);
		glVertex2f(x + comp / 2, y + alt / 2);
		glVertex2f(x - comp / 2, y + alt / 2);
		glEnd();

	}
	/////////////////////////
	void SetMoveX(int m)
	{
		x += m;
	}
	void SetMoveY(int m)
	{
		y += m;
	}
	void SetX(int m)
	{
		x = m;
	}
	void SetY(int m)
	{
		y = m;
	}
	/////////////////////////
	float GetX()
	{
		return(x);
	}
	float GetY()
	{
		return(y);
	}
	/////////////////////////
	float GetHeightBy2()
	{
		return(alt / 2);
	}
	float GetWidthBy2()
	{
		return(comp / 2);
	}
	/////////////////////////
	float GetMenorX()
	{
		return(x - comp / 2);
	}
	float GetMaiorX()
	{
		return(x + comp / 2);
	}
	float GetMenorY()
	{
		return(y - alt / 2);
	}
	float GetMaiorY()
	{
		return(y + alt / 2);
	}
	////////////////////////

};
