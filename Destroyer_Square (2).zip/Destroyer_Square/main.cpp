// Destroyer_Square.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <GL/glut.h>
#include "GL/glew.h"
#include "GL/freeglut.h"
#include "player.h"
#include "bullet.h"
#include "enemy.h"
#include "vector"
#include <iostream>
#include <string>

using namespace std;

float q = 10;

int life = 1;
int score = 0;

float minMaxX = 300;
float minMaxY = 300;

float windowX = 600;
float windowY = 600;

bool mainMenu = true;
bool playing = false;
bool defeat = false;
bool victory = false;

bool retry = false;
bool pause = false;


Player playerPart1(0, -285, 24, 120);
Player playerPart2(0, -255, 30, 24);
Bullet bullet(playerPart1.GetX(), playerPart1.GetY() + 50, 10, 10);
vector<Enemy*> enemy;

/*----------------FUN��O QUE REINICIA O JOGO QUANDO O JOGADOR VENCE O PERDE------------------*/

void Reset()
{
	if (mainMenu == true)
	{
		playing = false;
	}
	else
	{
		playing = true;
	}

	defeat = false;
	victory = false;
	retry = false;

	life = 1;
	score = 0;

	playerPart1.SetX(0);
	playerPart2.SetX(0);

	bullet.SetX(playerPart1.GetX());
	bullet.SetY(playerPart1.GetY() + 50);

	for (Enemy * e : enemy)
	{
		e->SetAlive(true);
	}

}

/*-------------------------------------------------------------------------------------------*/


/*----------------------- FUN��O QUE ESCREVE A PONTUA��O -------------------------*/

void TextScore(void)
{
	if (mainMenu == false && playing == true)
	{
		char textScore1[7] = "Score:";
		char textScore2[20];

		//sprintf_s(textScore2, "%d", score);

		glColor3ub(0, 255, 0);

		glRasterPos3f(-290.0, -290.0, 0.0);

		/*for (int i = 0; i <= strlen(textScore1); i++)
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, textScore1[i]);

		for (int i = 0; i <= strlen(textScore2); i++)
			glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, textScore2[i]);*/
	}
}
/*--------------------------------------------------------------------------------*/


/*------------------- TEXTO QUE APARECE NA JANELA PRETA DE CONSOLE ------------------*/

void ConsoleText()
{
	std::cout << "------------- DESTROYER SQUARE -------------" << endl << endl;
	std::cout << "A NEW GAME HAS STARTED" << endl << endl;
}

/*-----------------------------------------------------------------------------------*/


/*------------------------------ CRIADOR DE INIMIGOS -----------------------------*/

void CreateEnemy()
{
	float x = -250;
	float y = 250;

	for (int i = 0; i < 40; i++, x += 55.5)
	{
		if (x > 250)
		{
			x = -250;
			y -= 50;
		}
		Enemy*e = new Enemy(x, y, 30, 30);
		enemy.push_back(e);
	}
}

/*-------------------------------------------------------------------------------*/


/*------------------ FUN��O QUE ESCREVER OS TEXTOS MAIORES ----------------------*/

void largerText(char *string, float x, float y, float r, float g, float b)
{
	glColor3ub(r, g, b);
	glRasterPos3f(x, y, 0.0);
	while (*string)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *string++);
}

/*-------------------------------------------------------------------------------*/


/*------------------ FUN��O QUE ESCREVER OS TEXTOS MENORES ----------------------*/

void minorText(char *string, float x, float y, float r, float g, float b)
{
	glColor3ub(r, g, b);
	glRasterPos3f(x, y, 0.0);
	while (*string)
		glutBitmapCharacter(GLUT_BITMAP_HELVETICA_12, *string++);
}

/*-------------------------------------------------------------------------------*/


/*---------------- FUN��O QUE ESCREVE AS OP��ES DE MENU ------------------*/

void Menu()
{
	minorText("Press (E) To Exit", 200, -290, 0, 200, 0);

	if (mainMenu == true)
	{
		largerText("Destroyer Square", -73, 0, 0, 180, 0);
		minorText("Press (N) To New Game", -68, -30, 0, 180, 0);
	}

	if (defeat == true)
	{
		largerText("Game Over", -47, 0, 200, 0, 0);
		minorText("You Lose!", -27, -30, 200, 0, 0);
		minorText("Press (R) To Retry", -51, -60, 200, 0, 0);
		minorText("Press (M) To Main Menu", -71, -80, 200, 0, 0);
	}

	if (victory == true)
	{
		largerText("Game Over", -47, 0, 0, 200, 0);
		minorText("You Won!", -27, -30, 0, 200, 0);
		minorText("Press (R) To Retry", -51, -60, 0, 200, 0);
		minorText("Press (M) To Main Menu", -71, -80, 0, 200, 0);
	}

	if (pause == true)
	{
		largerText("Paused", -30.5, 0, 0, 200, 0);
	}
}
/*--------------------------------------------------------------------*/

/*-------------------------------------------------------------- DESENHA TODOS OS OBJETOS ----------------------------------------------------------------*/
void Draw()
{
	/*for (int i = 0; i < 14; i++, y -= 50)
	{
	glVertex2f(-x, -y);
	glVertex2f(x, y);
	}*/
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClear(GL_COLOR_BUFFER_BIT);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	//gluOrtho2D(-minMaxX, minMaxX, -minMaxY, minMaxY);

	if (mainMenu == false && playing == true)
	{
		float x = 300;
		float y = 300;

		glColor3f(0.0f, 0.15f, 0.15f);
		glBegin(GL_LINES);
		for (int i = 0; i < 28; i++, x -= 25)
		{
			glVertex2f(-x, y);
			glVertex2f(-x, -y);
		}
		for (int i = 0; i < 28; i++, y -= 25)
		{
			glVertex2f(-x, -y);
			glVertex2f(x, -y);
		}
		glEnd();

		/*glColor3f(0.15f, 0.0f, 0.0f);
		glBegin(GL_LINES);
		glVertex2f(0, 300);
		glVertex2f(0, -300);

		glVertex2f(-300, 0);
		glVertex2f(300, 0);
		glEnd();*/

		////////////////////
		playerPart1.Draw();
		playerPart2.Draw();
		////////////////////
		bullet.Draw();
		////////////////////

		for (Enemy* e : enemy)
		{
			if (e->GetAlive() == true)
			{
				e->Draw();
			}

			if (e->Collision(bullet.GetMenorX(), bullet.GetMaiorX(), bullet.GetMenorY(), bullet.GetMaiorY()) == true && e->GetAlive() == true)
			{
				e->SetAlive(false);
				score += 1;
				std::cout << "SCORE: " << score << endl;
			}
		}

		if (score == 40)
		{
			victory = true;
		}
		TextScore();
	}
	Menu();

	glutSwapBuffers();
}
/*--------------------------------------------------------------------------------------------------------------------------------------------------------*/


/*--------------------------------------------------------------------- MOVIMENTO DA BALA ----------------------------------------------------------------*/

void MoveBullet(int valor)
{
	if (mainMenu == false && playing == true && defeat == false && victory == false && pause == false)
	{
		/*------------------------------------- CHAMA AS FUN��ES DA "Class Bullet" QUE DETERMINAM SEUS MOVIMENTOS ----------------------------------------*/
		bullet.SetSPEEDUpAndRight();
		bullet.SetUpAndRightWINDOW(minMaxX, minMaxY);
		bullet.SetUpAndRightPLAYER(playerPart1.GetMenorX(), playerPart1.GetMaiorX(), playerPart1.GetMenorY(), playerPart1.GetMaiorY(), minMaxX, minMaxY);
		bullet.SetUpAndRightPLAYER(playerPart2.GetMenorX(), playerPart2.GetMaiorX(), playerPart2.GetMenorY(), playerPart2.GetMaiorY(), minMaxX, minMaxY);
		/*------------------------------------------------------------------------------------------------------------------------------------------------*/

		if (bullet.GetMenorY() < -minMaxY - 50)
		{
			life -= 1;
			bullet.SetX(playerPart1.GetX());
			bullet.SetY(playerPart1.GetY() + 50);
			bullet.SetUp(true);
		}

		if (life <= 0)
		{
			defeat = true;
		}
	}

	glutPostRedisplay();
	glutTimerFunc(5, MoveBullet, 1);
}

/*--------------------------------------------------------------------------------------------------------------------------------------------------------*/


/*--------------------------- MOVIMENTO DO JOGADOR ----------------------------*/

void MovePlayer(int tecla, int x, int y)
{
	if (mainMenu == false && playing == true && defeat == false && victory == false && pause == false)
	{
		if (tecla == GLUT_KEY_RIGHT && playerPart1.GetMaiorX() < minMaxX)
		{
			playerPart1.SetMoveX(10);
			playerPart2.SetMoveX(10);
		}
		else
		{
			if (tecla == GLUT_KEY_LEFT && playerPart1.GetMenorX() > -minMaxX)
			{
				playerPart1.SetMoveX(-10);
				playerPart2.SetMoveX(-10);
			}
		}
	}

	glutPostRedisplay();
}

/*-----------------------------------------------------------------------------*/


/*------------------------ OP��ES DE MENU -------------------------*/

void Op��es(unsigned char tecla, int x, int y)
{
	//tecla = toupper(tecla);
	if (mainMenu == true)
	{
		if (tecla == 'n')
		{
			mainMenu = false;
			playing = true;
			ConsoleText();
		}
	}

	if (defeat == true || victory == true)
	{
		if (tecla == 'm')
		{
			mainMenu = true;
			Reset();
		}

		if (tecla == 'r')
		{
			retry = true;
			Reset();
			ConsoleText();
		}
	}

	if (mainMenu == false && playing == true && defeat == false && victory == false)
	{
		if (tecla == 'p')
		{
			pause = !pause;
		}
	}

	if (tecla == 'e')
	{
		//exit(0);
	}
	glutPostRedisplay();
}

/*-----------------------------------------------------------------*/


/*----------------------- FUN��O PRINCIPAL ------------------------*/

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(windowX, windowY);
	glutCreateWindow("Destroyer Square");


	CreateEnemy();
	glutDisplayFunc(Draw);
	glutSpecialFunc(MovePlayer);
	glutKeyboardFunc(Op��es);
	glutTimerFunc(5, MoveBullet, 1);


	glutPostRedisplay();
	glutMainLoop();
	return 0;
}

/*-----------------------------------------------------------------*/
